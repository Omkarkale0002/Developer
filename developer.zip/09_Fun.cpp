#include<iostream>
using namespace std;

int main()
{
 int a,b,c;
// public double Add(){
int Add();
{
	c = a + b;
	cout<<"The result is:"<<c<<endl;
	return 0;
}
Add(20,30);
}
