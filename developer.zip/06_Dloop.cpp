/*Performing Do-while loop */
#include<iostream>
using namespace std;

int main()
{
	int a=10;

	do						//do while loop
	{
	cout<<"The value of a is"<<a<<endl;
	a=a+1;
	}while(a<20);				//condition check
	
	return 0;
}
