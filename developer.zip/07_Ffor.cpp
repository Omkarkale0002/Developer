/*Multiple for loops to print the numbers*/
#include<iostream>
using namespace std;

int main()
  {
	for(int i=0;i<3;i++)                       //increment with 3
	{
		cout<<"The value of i= "<<i<<endl;
	}
	for(int j=3;j<6;j++)
	{
		cout<<"The value of j= "<<j<<endl;
	}
	for(int k=6;k<9;k++)
	{
		cout<<"The value of k= "<<k<<endl;
	}
	for(int l=9;l<12;l++)
	{
		cout<<"Thr value of l= "<<l<<endl;
	}
  }
