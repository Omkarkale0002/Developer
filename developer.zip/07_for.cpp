/*Performing For loop program*/
#include<iostream>
using namespace std;

int main()
{

	for(int i=10;i<20;i++)		//for inti condi incr
	{
	cout<<"The value is"<<i<<endl;
	}
}


