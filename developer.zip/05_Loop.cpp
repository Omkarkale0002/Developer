/*Performing While loop*/

#include<iostream>
using namespace std;

int main()
{
	int a=10;
	int b=20;
	while(a<20)		//while condition 
	{
		cout<<"The value is:"<<a<<endl;
		a++;
	}
}
