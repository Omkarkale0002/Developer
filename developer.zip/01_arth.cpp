/*Pre-increment postincrement of a value*/

#include<iostream>
using namespace std;

 int main()					//main
   {
	int a=10;				//int a

    	cout<<"The original value is:"<<a;	//value
     	a++;

    	cout<<"\nThe 1st increment is:"<<a;		
    	a++;						//first increment
    
	cout<<"\n The 2nd increment is:"<<a;
    	++a;						//second
    	
	a++;  
     	cout<<"\n The 3rd incrementis:"<<a;     	//third
   } 
